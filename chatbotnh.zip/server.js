const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const OpenAI = require("openai");

dotenv.config();
const app = express();
const port = 3000;

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

app.use(bodyParser.json());
app.use(express.static(".")); // Serve index.html

app.post("/api/chat", async (req, res) => {
  try {
    const userMessage = req.body.message;

    const chatResponse = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content:
            "Você é um assistente de vendas do curso NH Método. Responda de forma simpática, clara e objetiva. Explique que o curso ensina marketing digital com foco em celular, incluindo tráfego pago, vendas pelo Instagram, Shopee e estratégias para vender sem aparecer. Fale dos bônus e suporte. Use emojis. Se o cliente perguntar sobre como comprar ou preço, envie este link: https://pay.kiwify.com.br/uK4dyOj?afid=AUAKnJf5. Se quiser falar no WhatsApp, envie este link: https://wa.me/556293338966."
        },
        {
          role: "user",
          content: userMessage
        }
      ]
    });

    res.json({ response: chatResponse.choices[0].message.content });
  } catch (error) {
    console.error("Erro ao conectar com a OpenAI:", error);
    res.status(500).json({ response: "Erro ao processar sua mensagem." });
  }
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});